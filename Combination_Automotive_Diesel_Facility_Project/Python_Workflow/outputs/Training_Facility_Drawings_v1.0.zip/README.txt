Training Facility Drawings v1.0
Date: 2026-01-30

Files:
- Drawing_Legend_and_Layer_Guide.pdf
- DXF/ARCH_Plan.dxf
- DXF/ELEC_Plan.dxf
- DXF/PLUMB_Plan.dxf
- DXF/MECH_Plan.dxf
- DXF/EQUIP_Plan.dxf
- DXF/FURN_Plan.dxf

Notes:
- Scale: coordination-level; verify scale in CAD application.
- MEP shown is placeholder only and must be engineered by licensed professionals.
- For questions, contact the project lead.
